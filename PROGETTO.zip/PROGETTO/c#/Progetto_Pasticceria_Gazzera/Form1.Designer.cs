﻿
namespace Progetto_Pasticceria_Gazzera
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstOrdini = new ListBox();
            lstSpesa = new ListBox();
            openFileDialog1 = new OpenFileDialog();
            lstDispensa = new ListBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            lstRicette = new ListBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // lstOrdini
            // 
            lstOrdini.FormattingEnabled = true;
            lstOrdini.Location = new Point(14, 72);
            lstOrdini.Margin = new Padding(3, 4, 3, 4);
            lstOrdini.Name = "lstOrdini";
            lstOrdini.Size = new Size(233, 484);
            lstOrdini.TabIndex = 2;
            // 
            // lstSpesa
            // 
            lstSpesa.FormattingEnabled = true;
            lstSpesa.Location = new Point(651, 72);
            lstSpesa.Margin = new Padding(3, 4, 3, 4);
            lstSpesa.Name = "lstSpesa";
            lstSpesa.Size = new Size(233, 304);
            lstSpesa.TabIndex = 3;
            lstSpesa.SelectedIndexChanged += listBox2_SelectedIndexChanged;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // lstDispensa
            // 
            lstDispensa.FormattingEnabled = true;
            lstDispensa.Location = new Point(651, 432);
            lstDispensa.Margin = new Padding(3, 4, 3, 4);
            lstDispensa.Name = "lstDispensa";
            lstDispensa.Size = new Size(233, 124);
            lstDispensa.TabIndex = 4;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(14, 33);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(233, 27);
            textBox1.TabIndex = 5;
            textBox1.Text = "Ordini";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(651, 33);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(233, 27);
            textBox2.TabIndex = 6;
            textBox2.Text = "Lista della spesa";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(651, 393);
            textBox3.Margin = new Padding(3, 4, 3, 4);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(233, 27);
            textBox3.TabIndex = 7;
            textBox3.Text = "Dispensa";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(309, 33);
            textBox4.Margin = new Padding(3, 4, 3, 4);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(233, 27);
            textBox4.TabIndex = 9;
            textBox4.Text = "Ricette";
            // 
            // lstRicette
            // 
            lstRicette.FormattingEnabled = true;
            lstRicette.Location = new Point(309, 72);
            lstRicette.Margin = new Padding(3, 4, 3, 4);
            lstRicette.Name = "lstRicette";
            lstRicette.Size = new Size(233, 484);
            lstRicette.TabIndex = 10;
            // 
            // button1
            // 
            button1.Location = new Point(14, 591);
            button1.Name = "button1";
            button1.Size = new Size(870, 29);
            button1.TabIndex = 11;
            button1.Text = "CUCINA";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1010, 728);
            Controls.Add(button1);
            Controls.Add(lstRicette);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(lstDispensa);
            Controls.Add(lstSpesa);
            Controls.Add(lstOrdini);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }



        #endregion
        private ListBox lstOrdini;
        private ListBox lstSpesa;
        private OpenFileDialog openFileDialog1;
        private EventHandler btnCarica_Click_1;
        private ListBox lstDispensa;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private ListBox lstRicette;
        private Button button1;
    }
}
