﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Progetto_Pasticceria_Gazzera
{
    public partial class Form1 : Form
    {
        FileSystemWatcher? watcher;

        HashSet<string> fileHashProcessati = new HashSet<string>();

        Dictionary<string, List<string>> ricette =
            new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);

        List<string> dispensa = new List<string>()
        {
            "uova","farina","mascarpone"
        };

        Queue<List<string>> codaOrdini = new Queue<List<string>>();

        public Form1()
        {
            InitializeComponent();

            button1.Text = "Cucina Primo Ordine";

            CaricaRicette();
            MostraDispensa();
            AvviaWatcher();
        }

        // =========================
        // FILE WATCHER
        // =========================
        void AvviaWatcher()
        {
            string path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads"
            );

            watcher = new FileSystemWatcher(path)
            {
                Filter = "*.*",
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite
            };

            watcher.Created += OnFileEvent;
            watcher.Renamed += OnFileEvent;

            watcher.EnableRaisingEvents = true;
        }

        void OnFileEvent(object sender, FileSystemEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                string file = e.FullPath;

                if (file.EndsWith(".crdownload") ||
                    file.EndsWith(".tmp") ||
                    file.Contains("~"))
                    return;

                Task.Run(() =>
                {
                    string finalFile = WaitFileReady(file);
                    if (finalFile == null) return;

                    string hash = GetFileHash(finalFile);

                    lock (fileHashProcessati)
                    {
                        if (fileHashProcessati.Contains(hash))
                            return;

                        fileHashProcessati.Add(hash);
                    }

                    this.Invoke((MethodInvoker)(() =>
                    {
                        CaricaOrdineSicuro(finalFile);
                    }));
                });
            });
        }

        string WaitFileReady(string path)
        {
            for (int i = 0; i < 20; i++)
            {
                try
                {
                    using (FileStream fs =
                        new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        return path;
                    }
                }
                catch
                {
                    Task.Delay(200).Wait();
                }
            }

            return null;
        }

        string GetFileHash(string file)
        {
            using (var sha = SHA256.Create())
            using (var stream = File.OpenRead(file))
            {
                return Convert.ToBase64String(sha.ComputeHash(stream));
            }
        }

        void CaricaOrdineSicuro(string path)
        {
            var lines = File.ReadAllLines(path)
                            .Where(l => !string.IsNullOrWhiteSpace(l))
                            .ToList();

            codaOrdini.Enqueue(lines);

            AggiornaVisualizzazione();
        }

        // =========================
        // UI
        // =========================
        void AggiornaVisualizzazione()
        {
            lstOrdini.Items.Clear();
            lstRicette.Items.Clear();
            lstSpesa.Items.Clear();

            HashSet<string> spesaTotale = new HashSet<string>();
            int numeroOrdine = 1;

            foreach (var ordine in codaOrdini)
            {
                lstOrdini.Items.Add($"===== ORDINE {numeroOrdine} =====");
                lstRicette.Items.Add($"===== ORDINE {numeroOrdine} =====");

                foreach (var riga in ordine)
                {
                    lstOrdini.Items.Add(riga);

                    if (IsRigaNonValida(riga))
                        continue;

                    string nomeRicetta = EstraiNomeRicetta(riga);

                    if (string.IsNullOrWhiteSpace(nomeRicetta))
                        continue;

                    string key = TrovaRicetta(nomeRicetta);

                    if (key == null)
                    {
                        lstRicette.Items.Add($"❌ Ricetta non trovata: {nomeRicetta}");
                        continue;
                    }

                    lstRicette.Items.Add($"🍰 {key}");

                    foreach (var ingrediente in ricette[key])
                    {
                        lstRicette.Items.Add($"   - {ingrediente}");

                        if (!dispensa.Contains(ingrediente))
                            spesaTotale.Add(ingrediente);
                    }

                    lstRicette.Items.Add("");
                }

                lstRicette.Items.Add("---------------------------");
                numeroOrdine++;
            }

            foreach (var i in spesaTotale)
                lstSpesa.Items.Add(i);
        }

        // =========================
        // FILTRI RIGHE (ticket/cliente/totale)
        // =========================
        bool IsRigaNonValida(string riga)
        {
            if (string.IsNullOrWhiteSpace(riga))
                return true;

            string l = riga.ToLower().Trim();

            return l.StartsWith("cliente")
                || l.StartsWith("ticket")
                || l.StartsWith("note")
                || l.StartsWith("totale")
                || l.StartsWith("ordine")
                || l.StartsWith("id");
        }

        // =========================
        // PARSER RICETTA (FIX DEFINITIVO)
        // =========================
        string EstraiNomeRicetta(string riga)
        {
            if (string.IsNullOrWhiteSpace(riga))
                return "";

            riga = riga.Trim();

            // rimuove (x6), (x1), ecc.
            while (riga.Contains("(") && riga.Contains(")"))
            {
                int start = riga.IndexOf("(");
                int end = riga.IndexOf(")");

                if (start < end)
                    riga = riga.Remove(start, end - start + 1);
                else
                    break;
            }

            riga = riga.Trim();

            // rimuove " x1", " x6"
            int index = riga.ToLower().IndexOf(" x");
            if (index > 0)
                riga = riga.Substring(0, index);

            return riga.Trim();
        }

        // =========================
        // NORMALIZZAZIONE (accents fix)
        // =========================
        string Normalizza(string s)
        {
            return s.ToLower()
                .Replace("è", "e")
                .Replace("é", "e")
                .Replace("ì", "i")
                .Replace("ò", "o")
                .Replace("à", "a")
                .Trim();
        }

        // =========================
        // MATCH RICETTA ROBUSTO
        // =========================
        string TrovaRicetta(string nome)
        {
            return ricette.Keys.FirstOrDefault(k =>
                Normalizza(k) == Normalizza(nome));
        }

        // =========================
        // DISPENSA
        // =========================
        void MostraDispensa()
        {
            lstDispensa.Items.Clear();

            foreach (var i in dispensa)
                lstDispensa.Items.Add(i);
        }

        // =========================
        // RICETTE COMPLETE
        // =========================
        void CaricaRicette()
        {
            ricette.Clear();

            ricette.Add("Tiramisù", new List<string>
            {
                "uova","mascarpone","zucchero","caffè","biscotti savoiardi","cacao"
            });

            ricette.Add("Torta al cioccolato", new List<string>
            {
                "cioccolato","farina","uova","zucchero","burro","lievito"
            });

            ricette.Add("Cheesecake alle fragole", new List<string>
            {
                "formaggio spalmabile","mascarpone","biscotti","burro","zucchero","fragole"
            });

            ricette.Add("Muffin al cioccolato", new List<string>
            {
                "farina","uova","zucchero","cioccolato","latte","lievito","burro"
            });

            ricette.Add("Macaron", new List<string>
            {
                "mandorle","zucchero a velo","albumi","zucchero"
            });

            ricette.Add("Brownie", new List<string>
            {
                "cioccolato","burro","uova","farina","zucchero"
            });

            ricette.Add("Cannolo", new List<string>
            {
                "ricotta","zucchero","farina","cannella","olio"
            });

            ricette.Add("Torta di mele", new List<string>
            {
                "mele","farina","uova","zucchero","burro","lievito"
            });

            ricette.Add("Bignè", new List<string>
            {
                "farina","uova","burro","latte","crema pasticcera"
            });

            ricette.Add("Pannacotta", new List<string>
            {
                "panna","zucchero","gelatina","vaniglia"
            });
        }

        // =========================
        // CUOCI ORDINE
        // =========================
        private void button1_Click(object sender, EventArgs e)
        {
            if (codaOrdini.Count > 0)
            {
                codaOrdini.Dequeue();
                MessageBox.Show("Ordine cucinato!");
                AggiornaVisualizzazione();
            }
        }
    }
} 